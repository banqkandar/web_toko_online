<?php 
require_once("config.php");
session_start();
if (!isset($_SESSION['pelanggan'])) {
    header("login.php");
}
$id_pelanggan = $_SESSION['pelanggan'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?=deskripsi;?>">
    <meta name="author" content="<?=peimilik;?>">
    <meta name="keywords" content="TokoSantuy">
    <title>
        Riwayat Pembelian - <?=nama;?>
    </title>
    <meta name="keywords" content="">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script src="js/respond.min.js"></script>

    <link rel="shortcut icon" href="favicon.png">
</head>
<body>
<?php include("navbar.php");?>

    <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">

                    <ul class="breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li>Akun Saya</li>
                    </ul>

                </div>

                <div class="col-md-3">
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Menu Akun</h3>
                        </div>

                        <div class="panel-body">

                            <ul class="nav nav-pills nav-stacked">
                                <li class="active">
                                    <a href="orderansaya.php"><i class="fa fa-list"></i> Riwayat Pembelian</a>
                                </li>
                                <li>
                                    <a href="akunsaya.php"><i class="fa fa-user"></i> Akun Saya</a>
                                </li>
                                <li>
                                    <a href="index.html"><i class="fa fa-sign-out"></i> Logout</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>

                 <div class="col-md-9" id="customer-order">
                    <div class="box">
                        <h1>Contact Form</h1>

                        <div class="form-area">  
                            <form action="captcha/validate.php" method="POST">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="name" name="nama" placeholder="Name" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                                        </div>
                                        <div class="form-group">
                                        <textarea class="form-control" type="textarea" id="message" name="pesan" placeholder="Message" maxlength="140" rows="7"></textarea>            
                                        </div>
                                        <div class="form-group">
                                            Masukkan CAPTCHA<input  type="text" class="form-control" name="captcha" ><img src="captcha/captcha.php" /><br>
                                        </div>
                                        <input class="btn btn-success" type="submit" name="submit" value="Kirim">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php include("footer.php");?>

</body>

</html>
