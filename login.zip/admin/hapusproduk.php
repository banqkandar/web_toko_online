<?php 

$ambil = $koneksi->query("SELECT * FROM produk where id_produk='$_GET[id]'");
$pecah = $ambil->fetch_assoc();
$gambar = $pecah['gambar'];
if (file_exists("../gambar/$gambar")) 
{
	unlink("../gambar/$gambar");
}

$koneksi->query("DELETE FROM produk where id_produk='$_GET[id]'");
echo "<script>alert('Produk Berhasil Dihapus');</script>";
echo "<script>location='".web."admin/produk'</script>";
?>