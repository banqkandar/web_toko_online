      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Produk</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Ubah Produk</div>
        <div class="card-body">
          <form method="post" enctype="multipart/form-data">
          <?php 
            if (isset($_POST['ubah'])) {
              $namagambar = $_FILES['gambar']['name'];
              $lokasigambar = $_FILES['gambar']['tmp_name'];
              if (!empty($lokasigambar)) {
                move_uploaded_file($lokasigambar, "../gambar/$namagambar");
                $koneksi ->query("UPDATE produk SET nama_produk='$_POST[nama]',harga_produk='$_POST[harga]',berat='$_POST[berat]',gambar='$namagambar',deskripsi_produk='$_POST[deskripsi]' WHERE id_produk='$_GET[id]'");
              }else{
                $koneksi ->query("UPDATE produk SET nama_produk='$_POST[nama]', harga_produk='$_POST[harga]',berat='$_POST[berat]', deskripsi_produk='$_POST[deskripsi]' WHERE id_produk='$_GET[id]'");
              }
              echo "<script>alert('Data Produk telah diubah');</script>";
              echo "<script>location='".web."admin/produk';</script>";
            }
            $ambil = $koneksi ->query("SELECT * FROM produk WHERE id_produk='$_GET[id]'");
            $pecah = $ambil -> fetch_assoc();
          ?>
            <div class="form-group">
              <label>Nama Produk</label>
              <input type="text" class="form-control" name="nama" value="<?php echo $pecah['nama_produk']; ?>">
              </div>
            <div class="form-group">
              <label>Harga (Rp)</label>
              <input type="number" class="form-control" name="harga" value="<?php echo $pecah['harga_produk']; ?>">
            </div>
            <div class="form-group">
              <label>Berat (Gr)</label>
              <input type="number" class="form-control" name="berat" value="<?php echo $pecah['berat']; ?>">
            </div>
            <div class="form-group">
              <label>Deskripsi Produk</label>
              <textarea class="form-control" name="deskripsi" rows="10"><?php echo $pecah['deskripsi_produk']; ?></textarea>
            </div>
            <div class="form-group">
              <img src="<?=web;?>gambar/<?php echo $pecah['gambar'] ?>" width="200">
            </div>
            <div class="form-group">
              <label>Ganti Gambar</label>
              <input type="file" class="form-control" name="gambar">
            </div>
            <button class="btn btn-primary" name="ubah">Simpan</button>
          </form>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>

