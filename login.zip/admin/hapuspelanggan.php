<?php 

$ambil = $koneksi->query("SELECT * FROM pelanggan where id_pelanggan='$_GET[id]'");
$pecah = $ambil->fetch_assoc();

$koneksi->query("DELETE FROM pelanggan where id_pelanggan='$_GET[id]'");
echo "<script>alert('Pelanggan Berhasil Dihapus');</script>";
echo "<script>location='".web."admin/pelanggan'</script>";
?>