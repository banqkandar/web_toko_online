      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Produk</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Tambah Produk</div>
        <div class="card-body">
          <form method="post" enctype="multipart/form-data">
          <?php 
            if (isset($_POST['save'])) {
              $nama = $_FILES['gambar']['name'];
              $lokasi = $_FILES['gambar']['tmp_name'];
              move_uploaded_file($lokasi, "../gambar/".$nama);
              $koneksi->query("INSERT INTO produk(nama_produk,harga_produk,berat,gambar,deskripsi_produk) VALUES ('$_POST[nama]','$_POST[harga]','$_POST[berat]','$nama','$_POST[deskripsi]')");
              echo "<div class='alert alert-info'>Data Tersimpan</div>";
              echo "<meta http-equiv='refresh' content='1;url=".web."admin/produk'>";}
          ?>
            <div class="form-group">
              <label>Nama Produk</label>
              <input type="text" class="form-control" name="nama">
              </div>
            <div class="form-group">
              <label>Harga (Rp)</label>
              <input type="number" class="form-control" name="harga">
            </div>
            <div class="form-group">
              <label>Berat (Gr)</label>
              <input type="number" class="form-control" name="berat">
            </div>
            <div class="form-group">
              <label>Deskripsi Produk</label>
              <textarea class="form-control" name="deskripsi" rows="10"></textarea>
            </div>
            <div class="form-group">
              <label>Gambar Produk</label>
              <input type="file" class="form-control" name="gambar">
            </div>
            <button class="btn btn-primary" name="save">Simpan</button>
          </form>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>

